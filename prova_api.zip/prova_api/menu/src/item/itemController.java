package item;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/menu/items")
public class itemController {
    private final itemService service;

    public itemController(itemService service) {
        this.service = service;
    }
}
