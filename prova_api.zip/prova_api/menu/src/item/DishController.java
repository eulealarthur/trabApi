package item;

@RestController
@RequestMapping("/api/dishes")
public class DishController {
    @Autowired
    private DishService dishService;

    @GetMapping
    public List<Dish> getDishesByNameContainingIgnoreCase(String name) {
        return dishService.findDishesByNameContainingIgnoreCase(name);
    }

    @PostMapping
    public Dish createDish(@RequestBody Dish dish) {
        return dishService.saveDish(dish);
    }
}
