package item;

@Service
public class DishService {
    @Autowired
    private DishRepository dishRepository;

    public List<Dish> findDishesByNameContainingIgnoreCase(String name) {
        return dishRepository.findByNameContainingIgnoreCase(name);
    }

    public Dish saveDish(Dish dish) {
        return dishRepository.save(dish);
    }
}
