package item;

import org.springframework.stereotype.Service;

@Service
public class itemService {
    private final itemRepository repository;

    public itemService(itemRepository repository) {
        this.repository = repository;
    }
}
